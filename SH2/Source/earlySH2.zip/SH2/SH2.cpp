#include <iostream>
#include <time.h>
#include "SDL2-2.0.12/include/SDL.h"
#include "SDL2-2.0.12/include/SDL_image.h"

#define WW 1280
#define WH 720
#define DEG 3.14/180	//0.0175f
#define MAX 100

struct Hex
{
	int r;
	int b;
};

class SH2
{
public:
	bool quit = false;
	SDL_Window* window = nullptr;
	SDL_Renderer* renderer = nullptr;

	Hex* h[MAX]{ nullptr };

	SDL_Texture* tex = nullptr;

	bool spaced = false;
	bool mr = false;
	bool ml = false;

	float p = 270.0f;
	float a = 0.0f;
	float as = 0.0f;
	float rs = 1.0f;
	float x = 0.0f;
	float y = 0.0f;

	float tri[4][2] = { 0 };

	SH2()
	{
		SDL_Init(SDL_INIT_VIDEO);
		IMG_Init(IMG_INIT_PNG);
		SDL_CreateWindowAndRenderer(WW, WH, 0, &window, &renderer);

		h[0] = new Hex{ WH / 14, 63 };

		tex = IMG_LoadTexture(renderer, "nan.png");

		srand(time(0));
	}

	~SH2()
	{
		for (auto i : h)
		{
			delete i;
			i = nullptr;
		}
		IMG_Quit();
		SDL_Quit();
	}

	void Input()
	{
		//input events management
		SDL_Event event;
		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
				quit = true;
			if (event.button.button == SDL_BUTTON_LEFT)
			{
				if (event.type == SDL_MOUSEBUTTONDOWN)
					ml = true;
				if (event.type == SDL_MOUSEBUTTONUP)
					ml = false;
			}
			if (event.button.button == SDL_BUTTON_RIGHT)
			{
				if (event.type == SDL_MOUSEBUTTONDOWN)
					mr = true;
				if (event.type == SDL_MOUSEBUTTONUP)
					mr = false;
			}
		}
		SDL_PumpEvents();
		const Uint8* keyboard = SDL_GetKeyboardState(0);
		if (keyboard[SDL_SCANCODE_ESCAPE])
			quit = true;
		//input update stats
		{
			/*if (keyboard[SDL_SCANCODE_RIGHT])
				mr = true;
			if (keyboard[SDL_SCANCODE_LEFT])
				ml = true;*/
			if (keyboard[SDL_SCANCODE_1])
				a += 1.0f;
			if (keyboard[SDL_SCANCODE_2])
				a -= 1.0f;
			if (keyboard[SDL_SCANCODE_3])
				as += 0.03f;
			if (keyboard[SDL_SCANCODE_4])
				as -= 0.03f;
			if (keyboard[SDL_SCANCODE_5])
				rs += 0.1f;
			if (keyboard[SDL_SCANCODE_6])
				rs -= 0.1f;
			if (keyboard[SDL_SCANCODE_7])
				x += 0.1f;
			if (keyboard[SDL_SCANCODE_8])
				x -= 0.1f;
			if (keyboard[SDL_SCANCODE_9])
				y += 0.1f;
			if (keyboard[SDL_SCANCODE_0])
				y -= 0.1f;
		}
		//create new hex
		if (keyboard[SDL_SCANCODE_SPACE] && !spaced)
		{
			for (int i = 1; i < MAX; i++)
				if (h[i] == nullptr)
				{
					h[i] = new Hex{ WW / 2, rand() % 64 };
					break;
				}
			spaced = true;
		}
		if (keyboard[SDL_SCANCODE_LSHIFT] || !keyboard[SDL_SCANCODE_SPACE])
			spaced = false;
	}

	void Update()
	{
		if (ml)
			p -= 3.0f;
		if (mr)
			p += 3.0f;

		//update hexagons radius
		{
			for (int i = 1; i < MAX; i++)
				if (h[i] != nullptr)
				{
					h[i]->r -= rs;
					bool outOfBounds = !(h[i]->r + 50 > h[0]->r && h[i]->r < h[0]->r + (WW / 2));
					bool playerCollisionRadius = ((h[0]->r + 32) > h[i]->r && (h[0]->r + 32) < h[i]->r + 50);
					bool playerCollisionAngle = (h[i]->b >> int(p / 60) & 1);
					if (outOfBounds || (playerCollisionRadius && playerCollisionAngle))
					{
						delete h[i];
						h[i] = nullptr;
					}
				}
		}
		//update rotation angles
		{
			a += as;
			if (a >= 360.0f || a <= -360.0f)
				a = 0.0f;
			

			if (p >= 360.0f || p <= -360.0f)
				p = 0.0f;
		}
		//update player's triangle
		{
			tri[0][0] = WW / 2 + (h[0]->r + 32) * cosf(DEG * (0.0f + p + a));
			tri[0][1] = WH / 2 + (h[0]->r + 32) * sinf(DEG * (0.0f + p + a));
			tri[1][0] = WW / 2 + (h[0]->r + 24) * cosf(DEG * (6.0f + p + a));
			tri[1][1] = WH / 2 + (h[0]->r + 24) * sinf(DEG * (6.0f + p + a));
			tri[2][0] = WW / 2 + (h[0]->r + 24) * cosf(DEG * (-6.0f + p + a));
			tri[2][1] = WH / 2 + (h[0]->r + 24) * sinf(DEG * (-6.0f + p + a));
			tri[3][0] = WW / 2 + (h[0]->r + 32) * cosf(DEG * (0.0f + p + a));
			tri[3][1] = WH / 2 + (h[0]->r + 32) * sinf(DEG * (0.0f + p + a));
		}
		//set title stats
		{
			int hexCount = 0;
			for (int i = 0; i < MAX; i++)
				if (h[i] != nullptr)
					hexCount++;
			static char title[256];
			sprintf_s(title, 256, "_p(%.1f)_a(%.1f)_as(%.1f)_rs(%.1f)_x(%.1f)_y(%.1f)_/*p[+r-l]_a[+1-2]_as[+3-4]_rs[+5-6]_x[+7-8]_y[+9-0]*/_hexCount_{ %d }_", p, a, as, rs, x, y, hexCount);
			SDL_SetWindowTitle(window, title);
		}
	}

	void Draw()
	{
		//set background
		{
			SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
			SDL_RenderClear(renderer);
		}
		//draw player's triangle
		{
			SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
			for (int i = 0; i < 3; i++)
				SDL_RenderDrawLine(renderer, tri[i][0], tri[i][1], tri[i + 1][0], tri[i + 1][1]);
			SDL_RenderDrawLine(renderer, (WW / 2), (WH / 2), tri[0][0], tri[0][1]);
		}
		//draw hexagons
		{
			SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
			for (int i = 0; i < MAX; i++)
				if (h[i] != nullptr)
				{
					for (int ii = 0, n = h[i]->b; ii < 6; ii++, n /= 2)
						if (bool(n % 2))
						{
							SDL_Point lp[4];
							int k = (i == 0) ? (WW / 2) : 50;
							for (int iii = 0; iii < 4; iii++)
							{
								lp[iii].x = int(WW / 2 + (h[i]->r + k * (iii / 2)) * cosf(float(DEG) * (60.0f * (ii + (iii % 2)) + a)));
								lp[iii].y = int(WH / 2 + (h[i]->r + k * (iii / 2)) * sinf(float(DEG) * (60.0f * (ii + (iii % 2)) + a)));
							}
							//lp[iii].x *= (lp[iii].x < WW / 2) ? (1 / cosf(DEG * x)) : cosf(DEG * x);
							//lp[iii].y *= (lp[iii].y < WW / 2) ? (1 / cosf(DEG * y)) : cosf(DEG * y);
							SDL_RenderDrawLine(renderer, lp[0].x, lp[0].y, lp[1].x, lp[1].y);
							SDL_RenderDrawLine(renderer, lp[2].x, lp[2].y, lp[3].x, lp[3].y);
							SDL_RenderDrawLine(renderer, lp[0].x, lp[0].y, lp[2].x, lp[2].y);
							SDL_RenderDrawLine(renderer, lp[1].x, lp[1].y, lp[3].x, lp[3].y);
						}
				}
		}
		SDL_RenderCopy(renderer, tex, 0, 0);
		//render
		SDL_RenderPresent(renderer);
	}
};
//main
int main(int argc, char** argv)
{
	SH2* game = new SH2();
	while (!game->quit)
	{
		Uint32 st = SDL_GetTicks();
		game->Input();
		game->Update();
		game->Draw();
		Uint32 tt = SDL_GetTicks() - st;
		if (tt < 1000 / 60) SDL_Delay(1000 / 60 - tt);
	}
	delete game;
	game = nullptr;
	return 0;
}

//for (int i = 0; i < 6; i++, n /= 2) b[5 - i] = n % 2;
//for (int i = 5; i >= 0; i--) b[5 - i] = ((n >> i) & 1);//#include <bits/stdc++.h>
//if (fig->boo % (int)pow(10, fig->s - i) >= (int)pow(10, fig->s - 1 - i))

/*
	0	[000000]	16	[010000]	32	[100000]	48	[110000]
	1	[000001]	17	[010001]	33	[100001]	49	[110001]
	2	[000010]	18	[010010]	34	[100010]	50	[110010]
	3	[000011]	19	[010011]	35	[100011]	51	[110011]
	4	[000100]	20	[010100]	36	[100100]	52	[110100]
	5	[000101]	21	[010101]	37	[100101]	53	[110101]
	6	[000110]	22	[010110]	38	[100110]	54	[110110]
	7	[000111]	23	[010111]	39	[100111]	55	[110111]
	8	[001000]	24	[011000]	40	[101000]	56	[111000]
	9	[001001]	25	[011001]	41	[101001]	57	[111001]
	10	[001010]	26	[011010]	42	[101010]	58	[111010]
	11	[001011]	27	[011011]	43	[101011]	59	[111011]
	12	[001100]	28	[011100]	44	[101100]	60	[111100]
	13	[001101]	29	[011101]	45	[101101]	61	[111101]
	14	[001110]	30	[011110]	46	[101110]	62	[111110]
	15	[001111]	31	[011111]	47	[101111]	63	[111111]
*/